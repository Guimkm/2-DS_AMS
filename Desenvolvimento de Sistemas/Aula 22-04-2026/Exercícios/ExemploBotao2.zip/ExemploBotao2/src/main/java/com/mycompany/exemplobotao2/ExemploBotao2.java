package com.mycompany.exemplobotao2;

import java.awt.*;
import javax.swing.*;

public class ExemploBotao2 extends JFrame{
    JButton botao;
    ImageIcon icone;
    public ExemploBotao2() {
        super("Exemplo com JButton");
        Container tela = getContentPane();
        setLayout(null);
        icone = new ImageIcon("folder_open.gif");
        botao = new JButton("Abrir", icone);
        botao.setBounds(50, 20, 100, 20);
        tela.add(botao);
        setSize(400, 250);
        setVisible(true);
    }

    public static void main(String[] args) {
        ExemploBotao2 app = new ExemploBotao2();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
