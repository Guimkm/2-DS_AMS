package com.mycompany.exemplobotao3;

import java.awt.*;
import javax.swing.*;

public class ExemploBotao3 extends JFrame{
    JButton botao;
    ImageIcon icone;
    public ExemploBotao3() {
        super("Exemplo com JButton");
        Container tela = getContentPane();
        setLayout(null);
        icone = new ImageIcon("folder_open.gif");
        botao = new JButton(icone);
        botao.setBounds(50, 20, 100, 20);
        tela.add(botao);
        setSize(400, 250);
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        ExemploBotao3 app = new ExemploBotao3();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
