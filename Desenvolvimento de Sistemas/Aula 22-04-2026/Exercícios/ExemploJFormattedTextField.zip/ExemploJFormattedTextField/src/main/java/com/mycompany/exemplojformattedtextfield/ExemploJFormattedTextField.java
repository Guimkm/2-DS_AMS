package com.mycompany.exemplojformattedtextfield;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class ExemploJFormattedTextField extends JFrame{
    
    JLabel rotulocep, rotulotel, rotulocpf, rotulodata;
    JFormattedTextField cep, tel, cpf, data;
    MaskFormatter mascaracep, mascaratel, mascaracpf, mascaradata;
    
    public ExemploJFormattedTextField() {
        super("Exemplo com JFormattedTextField");
        Container tela = getContentPane();
        setLayout(null);
        
        rotulocep = new JLabel("CEP: ");
        rotulotel = new JLabel("telefone: ");
        rotulocpf = new JLabel("CPF: ");
        rotulodata = new JLabel("Data: ");
        rotulocep.setBounds(50, 40, 100, 20);
        rotulotel.setBounds(50, 80, 100, 20);
        rotulocpf.setBounds(50, 120, 100, 20);
        rotulodata.setBounds(50, 160, 100, 20);
    }

    public static void main(String[] args) {
        
    }
}
