package com.mycompany.calculadora;

// Import dos elementos
import javax.swing.JFrame;

public class Principal {
    
        public static void main(String[] args) {
    Menu_Principal app = new Menu_Principal();   // inicia a pagina
    app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //EXIT_ON_CLOSE serve para finalizar a aplicação Java inteira quando o usuário clica no botão de fechar (o "X") da janela JFrame.Sem essa instrução, o comportamento padrão do Java é apenas esconder a janela (HIDE_ON_CLOSE), mantendo o programa rodando em segundo plano e consumindo memória, mesmo após você fechar a janela.
    }
    
}
