package com.mycompany.calculadora;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Menu_Principal extends JFrame {
    
    private Somar Somar;
    private Subtrair Subtrair;
    private Multiplicar Multiplicar;
    private Dividir Dividir;
    private Razao Razao;
    
    JLabel titulo, txt, soma, sub, mult, div, raiz, sair;
    JTextField input;
    JButton botao;
    
    public Menu_Principal() {
        super("Menu Principal");
            Container tela = getContentPane();
            setLayout(null);
            tela.setBackground(new Color(240, 240, 240));
                titulo = new JLabel("Menu Calculadora");
                txt = new JLabel("Escreva um número para escolher a ação desejada");
                soma = new JLabel("1 - Soma");
                sub = new JLabel("2 - Subtração");
                mult = new JLabel("3 - Multiplicação");
                div = new JLabel("4 - Divisão");
                raiz = new JLabel("5 - Raiz");
                sair = new JLabel("6 - Sair");
                input = new JTextField(10);
                botao = new JButton("Proseguir");
                
                
                
                titulo.setForeground(Color.red);
                titulo.setFont(new Font("Arial", Font.BOLD, 20));
                txt.setFont(new Font("Arial", Font.BOLD, 14));
                soma.setFont(new Font("Arial", Font.BOLD, 14));
                sub.setFont(new Font("Arial", Font.BOLD, 14));
                mult.setFont(new Font("Arial", Font.BOLD, 14));
                div.setFont(new Font("Arial", Font.BOLD, 14));
                raiz.setFont(new Font("Arial", Font.BOLD, 14));
                sair.setFont(new Font("Arial", Font.BOLD, 14));
                
                titulo.setBounds(150, 20, 200, 30);
                titulo.setHorizontalAlignment(JLabel.CENTER); // alinha o horizontalmente
                
                soma.setBounds(70, 70, 100, 20);
                sub.setBounds(70, 110, 100, 20);
                mult.setBounds(70, 150, 200, 20);
                div.setBounds(70, 190, 100, 20);
                raiz.setBounds(70, 230, 100, 20);
                sair.setBounds(70, 270, 100, 20);
                txt.setBounds(70, 310, 360, 20);
                input.setBounds(150, 340, 200, 25);
                botao.setBounds(200, 390, 100, 25);
                botao.setBackground(Color.white);
                getRootPane().setDefaultButton(botao); // Serve para passar o foco para um determinado botão assim que você pressionar a tecla enter.
        
        
        botao.addActionListener(
                    new ActionListener(){
                        public void actionPerformed(ActionEvent e) {
                            int num;
                            num = Integer.parseInt(input.getText());
                            
                            // Switch case para poder definir o tipo de calculo escolhido para executar;
                            switch(num) {
                                
                                // cases para abrir a paginas onde será feito cada calculo, e fechar o menu inicial.
                                case 1:
                                    Somar = new Somar();
                                    Somar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                    Somar.setVisible(true);
                                    setVisible(false);
                                break;
                                
                                case 2:
                                    Subtrair = new Subtrair();
                                    Subtrair.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                    Subtrair.setVisible(true);
                                    setVisible(false);
                                break;
                                
                                case 3:
                                    Multiplicar = new Multiplicar();
                                    Multiplicar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                    Multiplicar.setVisible(true);
                                    setVisible(false);
                                break;
                                
                                case 4:
                                    Dividir = new Dividir();
                                    Dividir.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                    Dividir.setVisible(true);
                                    setVisible(false);
                                break;
                                
                                case 5:
                                    Razao = new Razao();
                                    Razao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                    Razao.setVisible(true);
                                    setVisible(false);
                                break;
                                
                                case 6:
                                    System.exit(0);
                                break;
                                
                                default:
                                    JOptionPane.showMessageDialog(null, "Valor invalido!");
                                break;
                            }
                        }
                    }
        );
        
        tela.add(titulo);
        tela.add(soma);
        tela.add(sub);
        tela.add(mult);
        tela.add(div);
        tela.add(raiz);
        tela.add(sair);
        tela.add(txt);
        tela.add(input);
        tela.add(botao);
        
        setResizable(false);
        setSize(500, 500);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}