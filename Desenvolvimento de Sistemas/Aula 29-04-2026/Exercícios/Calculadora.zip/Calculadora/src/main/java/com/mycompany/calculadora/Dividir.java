package com.mycompany.calculadora;

// import dos elementos
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Classe para o calculo de divisão
public class Dividir extends JFrame{
    
    // Criação dos atributos
    JLabel titulo, txt1, txt2, res;
    JTextField input1, input2;
    JButton botao;
    JTextArea txt_res;
    
        // Método para a criação da pagina de divisão
        public Dividir() {
            super("Calculando a divisão");
            Container tela = getContentPane();
            setLayout(null);
            tela.setBackground(new Color(240, 240, 240));
            
            // Difinição dos atributos
            titulo = new JLabel("Dividindo");
            txt1 = new JLabel("Numero 1");
            txt2 = new JLabel("Numero 2");
            res = new JLabel("");
            input1 = new JTextField(10);
            input2 = new JTextField(10);
            botao = new JButton("Calcular");
            txt_res = new JTextArea("");
            
            // Adição da ação do botão
            botao.addActionListener(
                    new ActionListener(){
                        public void actionPerformed(ActionEvent e) {
                            double num1 = Double.parseDouble(input1.getText()); // Coleta do primeiro numero
                            double num2 = Double.parseDouble(input2.getText()); // Coleta do segundo numero
                            double r = num1 / num2; // Calculo da divisão
                            txt_res.setText("O resultado da divisão de " + num1 + " por " + num2 + " é igual a:"); // Adiciona o texto da resposta
                            res.setText(r+""); // adiciona a resposta
                            
                        }
                    }
            );
            
            // Alterando a estetica das fontes
            titulo.setForeground(Color.red);
            res.setForeground(Color.red);
            titulo.setFont(new Font("Arial", Font.BOLD, 20));
            txt1.setFont(new Font("Arial", Font.BOLD, 14));
            txt2.setFont(new Font("Arial", Font.BOLD, 14));
            txt_res.setFont(new Font("Arial", Font.BOLD, 14));
            res.setFont(new Font("Arial", Font.BOLD, 20));
            
            // Alterando a posição dos elementos da pagina
            titulo.setBounds(100,20,200,30);
            titulo.setHorizontalAlignment(JLabel.CENTER);
            
            txt1.setBounds(95,70,200,20);
            input1.setBounds(95,90,200,25);
            txt2.setBounds(95,130,200,20);
            input2.setBounds(95,150,200,25);
            
            botao.setBounds(145,190,100,25);
            botao.setBackground(Color.white);
            getRootPane().setDefaultButton(botao);
            
            txt_res.setBounds(60,230,280,40);
            txt_res.setLineWrap(true);
            txt_res.setWrapStyleWord(true);
            txt_res.setBackground(new Color(240, 240, 240));
            
            res.setBounds(60,260,280,60);
            res.setHorizontalAlignment(JLabel.CENTER);
            
            // Adicionando os elementos
            tela.add(titulo);
            tela.add(txt1);
            tela.add(txt2);
            tela.add(input1);
            tela.add(input2);
            tela.add(botao);
            tela.add(txt_res);
            tela.add(res);
           
        // Cofigurações basicas da pagina
        setResizable(false);
        setSize(400, 400);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
