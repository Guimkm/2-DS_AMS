package com.mycompany.calculadora;

// Importa os elementos nescessarios
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Classe da pagina de soma
public class Somar extends JFrame{
    
    // criação dos atributos
    JLabel titulo, txt1, txt2, res;
    JTextField input1, input2;
    JButton botao;
    JTextArea txt_res; // serve para textos grandes
    
        // Método para criar a pagina de soma
        public Somar() {
            super("Calculando a soma");
            Container tela = getContentPane();
            setLayout(null);
            tela.setBackground(new Color(240, 240, 240)); // background da pagina
            
            // Definição dos atributos
            titulo = new JLabel("Somando");
            txt1 = new JLabel("Numero 1");
            txt2 = new JLabel("Numero 2");
            res = new JLabel("");
            input1 = new JTextField(10);
            input2 = new JTextField(10);
            botao = new JButton("Calcular");
            txt_res = new JTextArea("");
            
            // Criação da ação do botão
            botao.addActionListener(
                    new ActionListener(){
                        public void actionPerformed(ActionEvent e) {
                            double num1 = Double.parseDouble(input1.getText()); // pegando o primeiro numero
                            double num2 = Double.parseDouble(input2.getText()); // pegando o segundo numero
                            double r = num1 + num2; // Calculo da soma
                            txt_res.setText("O resultado da soma entre " + num1 + " e " + num2 + " é igual a:"); // Texto da resposta
                            res.setText(r+""); // Definição do texto para o numero do resultado
                        }
                    }
            );
            
            // Alterando a estetica das fontes
            titulo.setForeground(Color.red);
            res.setForeground(Color.red);
            titulo.setFont(new Font("Arial", Font.BOLD, 20));
            txt1.setFont(new Font("Arial", Font.BOLD, 14));
            txt2.setFont(new Font("Arial", Font.BOLD, 14));
            txt_res.setFont(new Font("Arial", Font.BOLD, 14));
            res.setFont(new Font("Arial", Font.BOLD, 20));
            
            // Ajustando o posicionamento dos elementos
            titulo.setBounds(100,20,200,30);
            titulo.setHorizontalAlignment(JLabel.CENTER);
            
            txt1.setBounds(100,70,200,20);
            input1.setBounds(100,90,200,25);
            txt2.setBounds(100,130,200,20);
            input2.setBounds(100,150,200,25);
            
            botao.setBounds(150,190,100,25);
            botao.setBackground(Color.white);
            getRootPane().setDefaultButton(botao);
            
            txt_res.setBounds(60,230,280,40);
            txt_res.setLineWrap(true);        // Habilita a quebra de linha
            txt_res.setWrapStyleWord(true);   // Quebra a linha nas palavras, não no meio delas
            txt_res.setBackground(new Color(240, 240, 240)); // Usei para que o backrgound do textArea não aparecese
            
            res.setBounds(60,260,280,60);
            res.setHorizontalAlignment(JLabel.CENTER);
            
            // Adição dos elementos na pagina
            tela.add(titulo);
            tela.add(txt1);
            tela.add(txt2);
            tela.add(input1);
            tela.add(input2);
            tela.add(botao);
            tela.add(txt_res);
            tela.add(res);
            
        // configurações basicas da pagina
        setResizable(false);
        setSize(400, 400);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}