package com.mycompany.calculadora;

// Import dos elementos
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Criação da classe do calculo da raiz
public class Razao extends JFrame{
    
    // Criação dos atributos
    JLabel titulo, txt, txt_res, res;
    JTextField input;
    JButton botao;
    
        // Metodo para criar a pagina do calcula da razão
        public Razao() {
        
            super("Calculando a raiz");
            Container tela = getContentPane();
            setLayout(null);
            tela.setBackground(new Color(240, 240, 240));
            
            // Definição dos atributos
            titulo = new JLabel("Calculo de raiz");
            txt = new JLabel("Numero:");
            res = new JLabel("");
            txt_res = new JLabel("");
            input = new JTextField(10);
            botao = new JButton("Calcular");
            
            // Criação da ação do botão
            botao.addActionListener(
                    new ActionListener(){
                        public void actionPerformed(ActionEvent e) {
                            double num = Double.parseDouble(input.getText()); // Coleta do numero
                            double r = Math.sqrt(num); // calculo da raiz
                            txt_res.setText("O resultado da raiz de " + num + " é igual a:"); // texto de resposta
                            res.setText(r+""); // implementação do resultado
                        }
                    }
            );
            
            // Alterando a estetica das fontes
            res.setForeground(Color.red);
            titulo.setForeground(Color.red);
            titulo.setFont(new Font("Arial", Font.BOLD, 20));
            txt.setFont(new Font("Arial", Font.BOLD, 14));
            txt_res.setFont(new Font("Arial", Font.BOLD, 14));
            res.setFont(new Font("Arial", Font.BOLD, 20));
            
            // posicionando os elementos
            titulo.setBounds(100,20,200,30);
            titulo.setHorizontalAlignment(JLabel.CENTER);
            
            txt.setBounds(95,70,200,20);
            input.setBounds(95,90,200,25);
            
            botao.setBounds(145,140,100,25);
            botao.setBackground(Color.white);
            getRootPane().setDefaultButton(botao);
            
            txt_res.setBounds(60,180,280,40);
            txt_res.setHorizontalAlignment(JLabel.CENTER);
            res.setBounds(60,210,280,60);
            res.setHorizontalAlignment(JLabel.CENTER);
            
            // Adição dos elementos na tela
            tela.add(titulo);
            tela.add(txt);
            tela.add(input);
            tela.add(botao);
            tela.add(txt_res);
            tela.add(res);
            
        // Configurações basicas da pagina
        setResizable(false);
        setSize(400, 320);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
