package com.mycompany.cadastrodecilente;

import javax.swing.*;
import java.awt.*;

public class CadastroDeCilente extends JFrame{
    JLabel titulo, txt1, txt2, txt3, txt4, txt5, txt6, txt7;
    JTextField input1, input2, input3, input4, input5, input6, input7;
    public CadastroDeCilente() {
        super("Cadastro de cliente");
        Container tela = getContentPane();
        setLayout(null);
        tela.setBackground(new Color(232, 232, 232));
            titulo = new JLabel("Cadastro de Cliente");
            txt1 = new JLabel("Nome");
            txt2 = new JLabel("CPF");
            txt3 = new JLabel("RG");
            txt4 = new JLabel("Endereço");
            txt5 = new JLabel("Cidade");
            txt6 = new JLabel("Estado");
            txt7 = new JLabel("CEP");
            input1 = new JTextField(80);
            input2 = new JTextField(20);
            input3 = new JTextField(20);
            input4 = new JTextField(20);
            input5 = new JTextField(20);
            input6 = new JTextField(20);
            input7 = new JTextField(10);
            titulo.setForeground(Color.red);
            titulo.setFont(new Font("Arial",Font.BOLD, 20));
            titulo.setBounds(180,20,300,50);
            txt1.setBounds(40,60,80,30);
            txt2.setBounds(40,120,80,30);
            txt3.setBounds(40,180,150,30);
            txt4.setBounds(40,240,150,30);
            txt5.setBounds(40,300,150,30);
            txt6.setBounds(40,360,150,30);
            txt7.setBounds(40,420,80,30);
            input1.setBounds(40,90,250,20);
            input2.setBounds(40,150,150,20);
            input3.setBounds(40,210,150,20);
            input4.setBounds(40,270,200,20);
            input5.setBounds(40,330,200,20);
            input6.setBounds(40,390,200,20);
            input7.setBounds(40,450,150,20);
            tela.add(titulo);
            tela.add(txt1);
            tela.add(txt2);
            tela.add(txt3);
            tela.add(txt4);
            tela.add(txt5);
            tela.add(txt6);
            tela.add(txt7);
            tela.add(input1);
            tela.add(input2);
            tela.add(input3);
            tela.add(input4);
            tela.add(input5);
            tela.add(input6);
            tela.add(input7);
            setSize(600, 600);
            setLocationRelativeTo(null);
            setVisible(true);
    }

    public static void main(String[] args) {
        CadastroDeCilente tela = new CadastroDeCilente();
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
