package com.mycompany.teste;

import javax.swing.*;
import java.awt.*;

public class Teste extends JFrame{
    JLabel txt1; // nova caixa de texto
    JTextField input; // Define um novo input de texto
    
    public Teste() {
    super("titulo"); // Titulo da pagina
    Container tela = getContentPane(); // pega a tela para poder adicionar algo nele depois
    setLayout(null);
        txt1 = new JLabel("KKKKKKKK");  // Define o que vai conter nesse atributo JLabel
        input = new JTextField(80); // derfine a quantidade de letras que caberam no input
        txt1.setBounds(50, 40, 80, 20); // define a pocição Y e X, e a largura e altursa respectivamente.
        input.setBounds(130, 40, 60, 20);
        txt1.setForeground(Color.red); // define a cor da escrita
        txt1.setFont(new Font("Arial", Font.BOLD, 10)); // com isso vc define a font, o negrito dela e seu tamanho,
        tela.add(txt1);
        tela.add(input);
        setSize(600,300); // tamanho da pagina
        setVisible(true); // deixar ela visivel
        setLocationRelativeTo(null); // define a pocição em que a pagina estará quando for aberta, nesse caso o null faz com q ela fique no centro,
    }

    public static void main(String[] args) {
        Teste mn = new Teste();
        mn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
