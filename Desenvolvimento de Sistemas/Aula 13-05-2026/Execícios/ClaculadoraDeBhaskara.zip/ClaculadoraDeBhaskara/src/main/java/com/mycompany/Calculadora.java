package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculadora extends JFrame{

    JLabel titulo, txta, txtb, txtc, x1, x1res, x2, x2res;
    JTextField input1, input2, input3;
    JButton botao;

    public Calculadora() {
        super("Calculadora de bhaskara");
        Container tela = getContentPane();
        setLayout(null);

        titulo = new JLabel("Calculadora Bhaskara");
        txta = new JLabel("Valor de a: ");
        txtb = new JLabel("Valor de b: ");
        txtc = new JLabel("Valor de c");
        x1 = new JLabel("X'");
        x1res = new JLabel("");
        x2 = new JLabel("X\"");
        x2res = new JLabel("");
        input1 = new JTextField(10);
        input2 = new JTextField(10);
        input3 = new JTextField(10);
        botao = new JButton("Calcular");

        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        txta.setFont(new Font("Arial", Font.PLAIN, 14));
        txtb.setFont(new Font("Arial", Font.PLAIN, 14));
        txtc.setFont(new Font("Arial", Font.PLAIN, 14));
        x1.setFont(new Font("Arial", Font.PLAIN, 14));
        x1res.setFont(new Font("Arial", Font.PLAIN, 14));
        x2.setFont(new Font("Arial", Font.PLAIN, 14));
        x2res.setFont(new Font("Arial", Font.PLAIN, 14));


        titulo.setBounds(0, 20, 400, 30);
        titulo.setHorizontalAlignment(JLabel.CENTER);

        txta.setBounds(20, 60, 200, 20);
        txtb.setBounds(20, 90, 200, 20);
        txtc.setBounds(20, 120, 200, 20);

        x1.setBounds(40, 180, 200, 20);
        x1res.setBounds(70, 180, 200, 20);
        x1res.setBackground(new Color(195, 195, 195));
        x2.setBounds(40, 210, 200, 20);
        x2res.setBounds(70, 210, 200, 20);

        input1.setBounds(100, 60, 200, 20);
        input2.setBounds(100, 90, 200, 20);
        input3.setBounds(100, 120, 200, 20);

        botao.setBounds(125, 150, 150, 30);

        botao.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double a = Double.parseDouble(input1.getText());
                        double b = Double.parseDouble(input2.getText());
                        double c = Double.parseDouble(input3.getText());
                        double del = Math.sqrt(Math.pow(b, 2) - 4 * a * c);
                        double Pos = (-b + del) / (2 * a);
                        double Neg = (-b - del) / (2 * a);
                        x1res.setText(""+Neg);
                        x2res.setText(""+Pos);
                    }
                }
        );

        tela.add(titulo);
        tela.add(txta);
        tela.add(txtb);
        tela.add(txtc);
        tela.add(x1);
        tela.add(x1res);
        tela.add(x2);
        tela.add(x2res);
        tela.add(input1);
        tela.add(input2);
        tela.add(input3);
        tela.add(botao);

        setResizable(false);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
