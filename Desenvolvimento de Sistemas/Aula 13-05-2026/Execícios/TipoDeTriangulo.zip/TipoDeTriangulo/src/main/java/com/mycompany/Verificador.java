package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Verificador extends JFrame{
    JLabel titulo, lado1, lado2, lado3, res;
    JTextField input1, input2, input3;
    JButton botao;

    public Verificador() {
        super("Verificador de triangulos");
        Container tela = getContentPane();
        setLayout(null);

        titulo = new JLabel("Verificador de tipo");
        lado1 = new JLabel("Lado 1:");
        lado2 = new JLabel("Lado 2:");
        lado3 = new JLabel("Lado 3:");
        res = new JLabel("");
        input1 = new JTextField(10);
        input2 = new JTextField(10);
        input3 = new JTextField(10);
        botao = new JButton("Verificar tipo");

        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        lado1.setFont(new Font("Arial", Font.PLAIN, 14));
        lado2.setFont(new Font("Arial", Font.PLAIN, 14));
        lado3.setFont(new Font("Arial", Font.PLAIN, 14));
        res.setFont(new Font("Arial", Font.PLAIN, 14));


        titulo.setBounds(0, 20, 400, 30);
        titulo.setHorizontalAlignment(JLabel.CENTER);

        lado1.setBounds(20, 60, 100, 20);
        lado2.setBounds(20, 90, 100, 20);
        lado3.setBounds(20, 120, 100, 20);

        input1.setBounds(100, 60, 100, 20);
        input2.setBounds(100, 90, 100, 20);
        input3.setBounds(100, 120, 100, 20);

        botao.setBounds(20, 150, 180, 25);

        res.setBounds(225, 95, 150, 40);
        res.setHorizontalAlignment(JLabel.CENTER);

        botao.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double l1 = Double.parseDouble(input1.getText());
                        double l2 = Double.parseDouble(input2.getText());
                        double l3 = Double.parseDouble(input3.getText());

                        if (l1 == l2 && l1 == l3) {
                            res.setText("Triângulo equilátero");
                        } else if(l1 == l2 || l1 == l3 || l2 == l3) {
                            res.setText("Triângulo isósceles");
                        } else {
                            res.setText("Triângulo escaleno");
                        }
                    }
                }
        );

        tela.add(titulo);
        tela.add(lado1);
        tela.add(lado2);
        tela.add(lado3);
        tela.add(res);
        tela.add(input1);
        tela.add(input2);
        tela.add(input3);
        tela.add(botao);

        setResizable(false);
        setSize(400, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
