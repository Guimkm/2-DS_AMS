package com.mycompany;
import javax.swing.*;
public class Principal {
    static void main(String[] args) {
        Verificador app = new Verificador();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
