package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Conversor extends JFrame{
    JLabel titulo, cel, fah, kel;
    JTextField input, res1, res2;
    JButton botao;

    public Conversor() {
        super("Conversor de temperatura");
        Container tela = getContentPane();
        setLayout(null);

        titulo = new JLabel("Conversor de temperatura");
        cel = new JLabel("Graus Celcius:");
        fah = new JLabel("Graus Fahrenheit:");
        kel = new JLabel("Graus Kelvin:");
        input = new JTextField(10);
        res1 = new JTextField(10);
        res2 = new JTextField(10);
        botao = new JButton("Verificar tipo");

        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        cel.setFont(new Font("Arial", Font.PLAIN, 14));
        fah.setFont(new Font("Arial", Font.PLAIN, 14));
        kel.setFont(new Font("Arial", Font.PLAIN, 14));


        titulo.setForeground(Color.blue);
        titulo.setBounds(0, 20, 400, 30);
        titulo.setHorizontalAlignment(JLabel.CENTER);

        cel.setBounds(40, 60, 100, 20);
        fah.setBounds(40, 100, 150, 20);
        kel.setBounds(40, 140, 100, 20);

        input.setBounds(170, 60, 150, 20);

        res1.setBounds(170, 100, 150, 20);
        res1.setEditable(false);
        res2.setBounds(170, 140, 150, 20);
        res2.setEditable(false);

        botao.setBounds(110, 190, 180, 25);

        botao.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double c = Double.parseDouble(input.getText());
                        double f = (c * 9/5) + 32;
                        double k = c + 273.15;
                        res1.setText(""+f);
                        res2.setText(""+k);
                    }
                }
        );

        tela.add(titulo);
        tela.add(cel);
        tela.add(fah);
        tela.add(kel);
        tela.add(input);
        tela.add(res1);
        tela.add(res2);
        tela.add(botao);

        setResizable(false);
        setSize(400, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
