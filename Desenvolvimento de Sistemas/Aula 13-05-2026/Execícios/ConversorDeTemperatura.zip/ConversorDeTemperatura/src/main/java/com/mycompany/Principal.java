package com.mycompany;
import javax.swing.*;

public class Principal {
    static void main(String[] args) {
        Conversor app = new Conversor();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
