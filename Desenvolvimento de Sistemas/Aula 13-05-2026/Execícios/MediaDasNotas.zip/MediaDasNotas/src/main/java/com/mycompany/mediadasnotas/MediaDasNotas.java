package com.mycompany.mediadasnotas;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MediaDasNotas extends JFrame {
    
    JLabel titulo, nota1, nota2, nota3, nota4, media;
    JTextField input1, input2, input3, input4;
    JButton botao;
    
    public MediaDasNotas() {
        super("Média");
        Container tela = getContentPane();
        tela.setLayout(null);
        
        titulo = new JLabel("Média de notas");
        nota1 = new JLabel("Primeira nota:");
        nota2 = new JLabel("Segunda nota:");
        nota3 = new JLabel("Terceira nota:");
        nota4 = new JLabel("Quarta nota:");
        media = new JLabel("");
        input1 = new JTextField(10);
        input2 = new JTextField(10);
        input3 = new JTextField(10);
        input4 = new JTextField(10);
        botao = new JButton("Calcular");
        
        titulo.setForeground(Color.red);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        nota1.setFont(new Font("Arial", Font.PLAIN, 14));
        nota2.setFont(new Font("Arial", Font.PLAIN, 14));
        nota3.setFont(new Font("Arial", Font.PLAIN, 14));
        nota4.setFont(new Font("Arial", Font.PLAIN, 14));
        media.setFont(new Font("Arial", Font.PLAIN, 14));
        
        titulo.setBounds(0, 20, 400, 20);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        nota1.setBounds(75, 60, 100, 20);
        input1.setBounds(75, 80, 100, 20);
        nota2.setBounds(75,120, 100, 20);
        input2.setBounds(75, 140, 100, 20);

        nota3.setBounds(220, 60, 100, 20);
        input3.setBounds(220, 80, 100, 20);
        nota4.setBounds(220, 120, 100, 20);
        input4.setBounds(220, 140, 100, 20);
        botao.setBounds(150, 190, 100, 30);
        media.setBounds(100, 230, 200, 20);
        media.setHorizontalAlignment(JLabel.CENTER);
        
        
        getRootPane().setDefaultButton(botao);
        
        botao.addActionListener(new ActionListener(){;
        public void actionPerformed(ActionEvent e) {
            double num1 = Double.parseDouble(input1.getText());
            double num2 = Double.parseDouble(input2.getText());
            double num3 = Double.parseDouble(input3.getText());
            double num4 = Double.parseDouble(input4.getText());
            double res = (num1 + num2 + num3 + num4) / 4;
            media.setText("A média das notas é:\n" + res);
        }});
        
        tela.add(titulo);
        tela.add(nota1);
        tela.add(nota2);
        tela.add(nota3);
        tela.add(nota4);
        tela.add(input1);
        tela.add(input2);
        tela.add(input3);
        tela.add(input4);
        tela.add(botao);
        tela.add(media);
        
        setSize(400, 300);
        setVisible(true);
        setLocationRelativeTo(null);
    }
}
