package com.mycompany.mediadasnotas;

import javax.swing.JFrame;

public class Principal {

    public static void main(String[] args) {
        MediaDasNotas app = new MediaDasNotas();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
