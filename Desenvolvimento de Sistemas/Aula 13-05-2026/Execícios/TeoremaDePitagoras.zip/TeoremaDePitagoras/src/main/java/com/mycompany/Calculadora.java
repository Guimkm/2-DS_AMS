package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculadora extends JFrame{

    JLabel titulo, txtb, txtc, res;
    JTextField input1, input2;
    JButton botao;

    public Calculadora() {
        super("Teorema de pitagoras");
        Container tela = getContentPane();
        setLayout(null);

        titulo = new JLabel("Calculando a hipotenusa");
        txtb = new JLabel("Valor do cateto b: ");
        txtc = new JLabel("Valor do cateto c: ");
        res = new JLabel("");
        input1 = new JTextField(10);
        input2 = new JTextField(10);
        botao = new JButton("Calcular");

        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        txtb.setFont(new Font("Arial", Font.PLAIN, 14));
        txtc.setFont(new Font("Arial", Font.PLAIN, 14));
        res.setFont(new Font("Arial", Font.PLAIN, 14));


        titulo.setBounds(0, 20, 400, 30);
        titulo.setHorizontalAlignment(JLabel.CENTER);

        txtb.setBounds(30, 60, 200, 20);
        txtc.setBounds(30, 120, 200, 20);

        input1.setBounds(30, 80, 200, 20);
        input2.setBounds(30, 140, 200, 20);

        botao.setBounds(125, 180, 150, 25);

        res.setBounds(30, 210, 340, 40);
        res.setHorizontalAlignment(JLabel.CENTER);

        botao.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double b = Double.parseDouble(input1.getText());
                        double c = Double.parseDouble(input2.getText());
                        double r = Math.sqrt(Math.pow(b, 2) + Math.pow(c, 2));
                        res.setText("A hipotenusa é igual a: " + r);
                    }
                }
        );

        tela.add(titulo);
        tela.add(txtb);
        tela.add(txtc);
        tela.add(input1);
        tela.add(input2);
        tela.add(botao);
        tela.add(res);

        setResizable(false);
        setSize(400, 350);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
