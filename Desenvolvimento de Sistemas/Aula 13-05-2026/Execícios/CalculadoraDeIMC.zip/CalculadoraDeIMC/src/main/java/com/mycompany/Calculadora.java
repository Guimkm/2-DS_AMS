package com.mycompany;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculadora extends JFrame {

    JLabel titulo, peso, altura, res;
    JTextField input1, input2;
    JButton botao;

    public Calculadora() {
        super("Calculadora de IMC");
        Container tela = getContentPane();
        setLayout(null);

        titulo = new JLabel("Calculadora de IMC");
        peso = new JLabel("Peso:");
        altura = new JLabel("Altura:");
        res = new JLabel("");
        input1 = new JTextField(10);
        input2 = new JTextField(10);
        botao = new JButton("Calcular");

        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        peso.setFont(new Font("Arial", Font.PLAIN, 14));
        altura.setFont(new Font("Arial", Font.PLAIN, 14));
        res.setFont(new Font("Arial", Font.PLAIN, 14));


        titulo.setBounds(0, 20, 400, 30);
        titulo.setHorizontalAlignment(JLabel.CENTER);

        peso.setBounds(20, 60, 100, 20);
        altura.setBounds(20, 90, 100, 20);

        input1.setBounds(100, 60, 100, 20);
        input2.setBounds(100, 90, 100, 20);

        botao.setBounds(20, 130, 180, 25);

        res.setBounds(225, 95, 250, 40);
        res.setHorizontalAlignment(JLabel.CENTER);

        botao.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        double peso = Double.parseDouble(input1.getText());
                        double alt = Double.parseDouble(input2.getText());
                        double r = peso / Math.pow(alt, 2);

                        if (r < 18) {
                            res.setText("Abaixo do peso ideal - IMC: " + r);
                        } else if(r > 18.5 && r < 24.99) {
                            res.setText("Peso Ideal - IMC: " + r);
                        } else {
                            res.setText("Acima do peso ideal - IMC: " + r);
                        }
                    }
                }
        );

        tela.add(titulo);
        tela.add(peso);
        tela.add(altura);
        tela.add(res);
        tela.add(input1);
        tela.add(input2);
        tela.add(botao);

        setResizable(false);
        setSize(500, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
